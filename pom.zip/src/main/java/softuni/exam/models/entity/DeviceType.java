package softuni.exam.models.entity;

public enum DeviceType {
    SMART_PHONE, TABLET, SMART_WATCH, LAPTOP
}
